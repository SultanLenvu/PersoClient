#include "service_object_environment.h"

ServiceObjectEnvironment::ServiceObjectEnvironment()
{

}
