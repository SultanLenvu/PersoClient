#ifndef ABSTRACTSERVICEOBJECTSPACE_H
#define ABSTRACTSERVICEOBJECTSPACE_H

class AbstractServiceObjectSpace {
 public:
  AbstractServiceObjectSpace() = default;
  virtual ~AbstractServiceObjectSpace() = default;
};

#endif  // ABSTRACTSERVICEOBJECTSPACE_H
