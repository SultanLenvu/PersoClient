#include "connectable_object.h"

ConnectableObject::ConnectableObject()
{

}
