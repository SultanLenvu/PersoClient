#ifndef SERVICEOBJECTENVIRONMENT_H
#define SERVICEOBJECTENVIRONMENT_H

#include "abstract_object_environment.h"

class ServiceObjectEnvironment : public AbstractObjectEnvironment
{
 public:
  ServiceObjectEnvironment();
};

#endif // SERVICEOBJECTENVIRONMENT_H
