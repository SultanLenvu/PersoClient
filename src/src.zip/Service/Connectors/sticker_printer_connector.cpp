#include "sticker_printer_connector.h"
