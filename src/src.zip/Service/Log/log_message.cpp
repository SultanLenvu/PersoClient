#include "log_message.h"

LogMessage::LogMessage(const QString& txt) {}
