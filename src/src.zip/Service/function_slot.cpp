#include "function_slot.h"

FunctionSlot::FunctionSlot()
{

}
