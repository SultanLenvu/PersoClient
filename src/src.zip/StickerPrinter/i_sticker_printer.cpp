#include "i_sticker_printer.h"
