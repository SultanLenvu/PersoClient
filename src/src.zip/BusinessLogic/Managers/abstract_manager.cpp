#include "abstract_manager.h"
