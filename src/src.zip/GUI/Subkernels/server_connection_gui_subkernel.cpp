#include "server_connection_gui_subkernel.h"

void ServerConnectionGuiSubkernel::connect() {
  emit clearLogDisplay_signal();
  emit connect_signal();
}

void ServerConnectionGuiSubkernel::disconnect() {
  emit clearLogDisplay_signal();
  emit disconnect_signal();
}

void ServerConnectionGuiSubkernel::echo() {
  emit clearLogDisplay_signal();
  emit echo_signal();
}

void ServerConnectionGuiSubkernel::launchProductionLine() {
  emit clearLogDisplay_signal();
  emit launchProductionLine_signal(param);
}

void ServerConnectionGuiSubkernel::shutdownProductionLine() {
  emit clearLogDisplay_signal();
  emit shutdownProductionLine_signal();
}

void ServerConnectionGuiSubkernel::getProductionLineData() {
  emit clearLogDisplay_signal();
  emit getProductionLineData_signal();
}

void ServerConnectionGuiSubkernel::requestBox() {
  emit clearLogDisplay_signal();
  emit requestBox_signal();
}

void ServerConnectionGuiSubkernel::getCurrentBoxData() {
  emit clearLogDisplay_signal();
  emit getCurrentBoxData_signal();
}

void ServerConnectionGuiSubkernel::refundCurrentBox() {
  emit clearLogDisplay_signal();
  emit refundCurrentBox_signal();
}

void ServerConnectionGuiSubkernel::completeCurrentBox() {
  emit clearLogDisplay_signal();
  emit completeCurrentBox_signal();
}

void ServerConnectionGuiSubkernel::releaseTransponder() {
  emit clearLogDisplay_signal();
  emit releaseTransponder_signal();
}

void ServerConnectionGuiSubkernel::confirmTransponderRelease() {
  emit confirmTransponderRelease_signal(param);
  emit clearLogDisplay_signal();
}

void ServerConnectionGuiSubkernel::rereleaseTransponder() {
  emit clearLogDisplay_signal();
  emit rereleaseTransponder_signal(param);
}

void ServerConnectionGuiSubkernel::confirmTransponderRerelease() {
  emit clearLogDisplay_signal();
  emit confirmTransponderRerelease_signal(param);
}

void ServerConnectionGuiSubkernel::rollbackTransponder() {
  emit clearLogDisplay_signal();
  emit rollbackTransponder_signal();
}

void ServerConnectionGuiSubkernel::getCurrentTransponderData() {
  emit clearLogDisplay_signal();
  emit getCurrentTransponderData_signal();
}

void ServerConnectionGuiSubkernel::getTransponderData() {
  emit clearLogDisplay_signal();
  emit getTransponderData_signal(param);
}

void ServerConnectionGuiSubkernel::printBoxSticker() {
  emit clearLogDisplay_signal();
  emit printBoxSticker_signal(param);
}

void ServerConnectionGuiSubkernel::printLastBoxSticker() {
  emit clearLogDisplay_signal();
  emit printLastBoxSticker_signal();
}

void ServerConnectionGuiSubkernel::printPalletSticker() {
  emit clearLogDisplay_signal();
  emit printPalletSticker_signal(param);
}

void ServerConnectionGuiSubkernel::printLastPalletSticker() {
  emit clearLogDisplay_signal();
  emit printLastPalletSticker_signal();
}

void ServerConnectionGuiSubkernel::generateDisconnectionAlert() {
  QMessageBox::critical(nullptr, "Ошибка", "Соединение с сервером оборвалось.",
                        QMessageBox::Ok);
}
