#include "sticker_printer_gui_subkernel.h"

void StickerPrinterGuiSubkernel::printLastTransponderSticker() {
  emit clearLogDisplay_signal();

  emit printLastTransponderSticker_signal();
}

void StickerPrinterGuiSubkernel::printTransponderSticker() {
  emit clearLogDisplay_signal();

  emit printTransponderSticker_signal(param);
}

void StickerPrinterGuiSubkernel::exec(const QStringList& script) {
  emit clearLogDisplay_signal();

  emit exec_signal(script);
}
