#include "abstract_user_interface.h"

AbstractUserInterface::AbstractUserInterface(QWidget *parent)
    : QWidget{parent}
{

}
